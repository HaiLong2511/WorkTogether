
<!DOCTYPE html>
<html lang="en">

<?php $__env->startSection('Title'); ?>
    Trang Chủ
<?php $__env->stopSection(); ?>
<body>
    <div class="container-xxl position-relative bg-white d-flex p-0">
        
        <!-- Sidebar Start -->
        
        <!-- Sidebar End -->
        <!-- Content Start -->
        <div class="content">
            <!-- Navbar Start -->
            <nav class="navbar navbar-expand bg-light navbar-light sticky-top px-4 py-0">
                <?php echo $__env->make('layout.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </nav>
            <?php echo $__env->make('layout.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- Navbar End -->
            <div class="container-fluid pt-4 px-4">
                <div class="row g-4">
                    <div class="col-sm-12 col-xl-12">
                        <div class="bg-light rounded h-100 p-4">
                            <h6 class="mb-4">Thêm Công Việc</h6>
                            <form action="<?php echo e(route('luucongviec')); ?>" method="post" enctype="multipart/form-data"><?php echo csrf_field(); ?>
                                <div class="form-floating mb-3">
                                    <input type="text" class="form-control" name="tencv" value="<?php echo e(old('tencv')); ?>">
                                    <label for="floatingInput">Tên Công Việc</label>
                                </div>
                                <div class="form-floating mb-3">
                                    <input type="Date" class="form-control" name="ngaykt" value="<?php echo e(old('ngaykt')); ?>">
                                    <label for="floatingInput">Hạn nộp</label>
                                </div>
                                <div class="form-floating mb-3">
                                    <textarea class="form-control" placeholder=""
                                    name="Mota" style="height: 150px;"><?php echo e(old('Mota')); ?></textarea>
                                    <label for="floatingTextarea">Mô tả công việc<span class="wpforms-required-label">*</span>
                                    </label>
                                </div>
                                <div class="form-floating mb-3">
                                    <select class="form-select" name="mucdocv"
                                        aria-label="Floating label select example">
                                        <option value="" selected>Vui lòng chọn mức độ ưu tiên</option>
                                            <option value ="0">Thấp</option>
                                            <option value ="1">Vừa</option>
                                            <option value ="2">Cao</option>
                                            <option value ="3">Gấp</option>
                                    </select>
                                    <label for="floatingSelect">Chọn mức độ ưu tiên</label>
                                </div>
                                <div class="mb-3">
                                    <label for="formFileMultiple" class="form-label">Chọn tệp hồ sơ</label>
                                    <input class="form-control" type="file" name="formFileMultiple[]" multiple>
                                </div>
                                <div class="form-floating mb-3">
                                    <div class="bg-light rounded h-100 p-4">
                                        <label>Chọn nhân viên</label>
                                        <select class="form-select" name="nhanvien[]" multiple aria-label="multiple select example">
                                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value = <?php echo e($item->MaNV); ?> <?php echo e(old('nhanvien')==$item->MaNV ? 'selected' : ''); ?> ><?php echo e($item->TenNV); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                                <button type="submit" class="btn btn-primary">Lưu</button>
                                <button type="reset" class="btn btn-primary">Hủy</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Footer Start -->
            <?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- Footer End -->
        </div>
        <!-- Content End -->


        <!-- Back to Top -->
        <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top"><i class="bi bi-arrow-up"></i></a>
    </div>

    <!-- JavaScript Libraries -->
    <?php echo $__env->make('layout.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Template Javascript -->
    <script src="<?php echo e(url('accessweb/js/main.js')); ?>"></script>
</body>

</html>
<?php echo $__env->make('layout.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layout.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\WorkTogether_4\resources\views/congviec/taocongviec.blade.php ENDPATH**/ ?>