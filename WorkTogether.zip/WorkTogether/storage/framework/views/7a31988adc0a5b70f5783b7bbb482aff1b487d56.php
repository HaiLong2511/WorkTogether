<!DOCTYPE html>
<html lang="en">
   
   <?php $__env->startSection('Title'); ?>
   Trang Chủ
   <?php $__env->stopSection(); ?>
   <body>
      <div class="container-xxl position-relative bg-white d-flex p-0">
         <!-- Sidebar Start -->
         
         <!-- Sidebar End -->
         <!-- Content Start -->
         <div class="content">
            <!-- Navbar Start -->
            <nav class="navbar navbar-expand bg-light navbar-light sticky-top px-4 py-0">
               <?php echo $__env->make('layout.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </nav>
            <?php if(session()->has('mess')): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
               <i class="fa fa-exclamation-circle me-2"></i><?php echo e(session('mess')); ?>

               <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
            <?php endif; ?>
            <?php if(session()->has('success')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
               <?php echo e(session('success')); ?>

               <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
            <?php endif; ?>
            <!-- Navbar End -->
            <div class="container-fluid pt-4 px-4">
               <div class="row g-4">
                  <div class="col-sm-12 col-xl-12">
                     <div class="bg-light rounded h-100 p-4">
                        <h6 class="mb-4">Danh sách nhân viên</h6>
                        <form class="d-none d-md-flex ms-4" action="<?php echo e(route('Searchnhanvien')); ?>" method="get">
                           <input class="form-control border-0" type="search" placeholder="Tìm kiếm" name="keywords">
                        </form>
                     </div>
                  </div>
                  <div class="col-sm-12 col-xl-12">
                     <div class="bg-light rounded h-100 p-4">
                        <div class="table-responsive">
                           <table class="table">
                              <thead>
                                 <tr>
                                    <th scope="col">Mã nhân viên</th>
                                    <th scope="col"><b>Tên nhân viên</b></th>
                                    <th scope="col"><b>Đơn vị</b></th>
                                    <th scope="col"><b>Chức vụ</b></th>
                                    <th scope="col"><b>Trạng thái</b></th>
                                    <th scope="col"><b>Thao tác</b></th>
                                 </tr>
                              </thead>
                              <tbody>
                                 <div>
                                    <?php $__currentLoopData = $list_user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                       <td><?php echo e($item->MaNV); ?></td>
                                       <td><?php echo e($item->TenNV); ?></td>
                                       <td> <?php echo e($item->TenPhong); ?></td>
                                       <td>  <?php echo e($item->TenQuyen); ?></td>
                                       <?php if($item->trangthai =='1'): ?>
                                            <td> Đang hoạt động </td>
                                       <?php else: ?>
                                            <td><?php echo e($item->trangthai =='0'); ?> Không hoạt động</td>
                                       <?php endif; ?>
                                      
                                       <td>
                                          <a href="<?php echo e(url('chuyentrangthai/')); ?>/<?php echo e($item->MaNV); ?>/<?php echo e($item->trangthai); ?>"><button type="button" class="btn btn-sm btn-sm-square btn-outline-primary m-2"><i class="fa fa-lock"></i></button>
                                          <a href="<?php echo e(url('chitietnhanvien/')); ?>/<?php echo e($item->MaNV); ?>">
                                             <button type="button" class="btn btn-sm btn-sm-square btn-outline-primary m-2"><i class="fa fa-info"></i></button>
                                       </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                 </div>
                              </tbody>
                           </table>
                           <div>
                           <?php echo e($list_user->links()); ?>

                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <!-- Footer Start -->
            <?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- Footer End -->
         </div>
         <!-- Content End -->
         <!-- Back to Top -->
         <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top"><i class="bi bi-arrow-up"></i></a>
      </div>
      <!-- JavaScript Libraries -->
      <?php echo $__env->make('layout.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <!-- Template Javascript -->
      <script src="<?php echo e(url('accessweb/js/main.js')); ?>"></script>
   </body>
</html>
<?php echo $__env->make('layout.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layout.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\WorkTogether\resources\views/user/list_nhanvien.blade.php ENDPATH**/ ?>