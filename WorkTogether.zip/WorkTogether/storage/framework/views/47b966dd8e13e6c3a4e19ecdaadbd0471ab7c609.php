

<!DOCTYPE html>
<html lang="en">

<?php $__env->startSection('Title'); ?>
    Trang Chủ
<?php $__env->stopSection(); ?>
<body>
    <div class="container-xxl position-relative bg-white d-flex p-0">
        <!-- Sidebar Start -->
        
        <!-- Sidebar End -->
        <!-- Content Start -->
        <div class="content">
            <!-- Navbar Start -->
            <nav class="navbar navbar-expand bg-light navbar-light sticky-top px-4 py-0">
                <?php echo $__env->make('layout.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </nav>
            <!-- Navbar End -->
             <!-- Table Start -->
            <div class="container-fluid pt-4 px-4">
                <div class="row g-4">
                    <div class="col-sm-12 col-xl-12">
                        <div class="bg-light rounded h-100 p-4">
                            <h2 class="page-header">Cập nhật mật khẩu</h2>
                            <form action="<?php echo e(route('Luudoimatkhau')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <div class="form-group" style="position: relative">
                                    <label for="email">Mật khẩu cũ:</label>                
                                    <input type="password" class="form-control" placeholder="" name="password_old" value=""> 
                                    <a style="position: absolute;top: 54%; right: 10px; color: #333" href="javascript:void(0)"><i class=""></i></a>
                                </div>
                                <div class="form-group" style="position: relative">
                                    <label for="email">Mật khẩu mới:</label>
                                    <input type="password" class="form-control" placeholder="" name="password" value=""> 
                                    <a style="position: absolute;top: 54%; right: 10px; color: #333" href="javascript:void(0)"><i class=""></i></a>
                                </div>
                                <div class="form-group" style="position: relative">
                                    <label for="email">Nhập lại mật khẩu mới:</label>
                                    <input type="password" class="form-control" placeholder="" name="password_confirm" value="">
                                    <a style="position: absolute;top: 54%; right: 10px; color: rgb(16, 15, 15)" href="javascript:void(0)"><i class=""></i></a>
                                </div>
                                <button type="submit" class="btn btn-primary">Cập nhật</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
                <!-- Table End -->
            <!-- Footer Start -->
            <?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- Footer End -->
        </div>
        <!-- Content End -->


        <!-- Back to Top -->
        <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top"><i class="bi bi-arrow-up"></i></a>
    </div>

    <!-- JavaScript Libraries -->
    <?php echo $__env->make('layout.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Template Javascript -->
    <script src="<?php echo e(url('accessweb/js/main.js')); ?>"></script>
</body>

</html>
<?php echo $__env->make('layout.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layout.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\WorkTogether\resources\views/doimatkhau.blade.php ENDPATH**/ ?>