
<!DOCTYPE html>
<html lang="en">

<?php $__env->startSection('Title'); ?>
    Trang Chủ
<?php $__env->stopSection(); ?>
<body>
    <div class="container-xxl position-relative bg-white d-flex p-0">
        <!-- Sidebar Start -->
        
        <!-- Sidebar End -->
        <!-- Content Start -->
        <div class="content">
            <!-- Navbar Start -->
            <nav class="navbar navbar-expand bg-light navbar-light sticky-top px-4 py-0">
                <?php echo $__env->make('layout.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </nav>
            <?php echo $__env->make('layout.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="container-fluid pt-4 px-4">
                    <div class="row g-4">
                        <div class="col-sm-12 col-xl-12">
                            <div class="bg-light rounded h-100 p-4">
                            <form action="<?php echo e(route('luuqa')); ?>" method="post" enctype="multipart/form-data"><?php echo csrf_field(); ?>
                                <h6 class="mb-4">Thêm câu hỏi</h6>
                                <div class="row mb-3">
                                    <label for="" class="col-sm-2 col-form-label">Tên công việc</label>
                                    <div class="col-sm-10">
                                        <select class="form-select mb-3" aria-label="Default select example" name="MaCV" >
                                            <option value = <?php echo e($data->MaCV); ?> seleted > <?php echo e($data->Tieude); ?></option>
                                        </select>
                                    </div>
                                </div>
                                <div class="row mb-3">
                                    <label for="" class="col-sm-2 col-form-label">Nội dung cần hỏi</label>
                                    <div class="col-sm-10">
                                        <textarea class="form-control" placeholder=""
                                        id="floatingTextarea" style="height: 150px;" name="noidung"> <?php echo e(old('noidung')); ?> </textarea>
                                    </div>
                                </div>
                                
                                 <button type="submit" class="btn btn-primary">Lưu</button>
                                <button type="reset" class="btn btn-primary">Hủy</button>
                            </form>
                            </div>
                        </div>
                    </div>
                </div> 
            <!-- Navbar End -->
            
            <!-- Footer Start -->
            <?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- Footer End -->
        </div>
        <!-- Content End -->


        <!-- Back to Top -->
        <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top"><i class="bi bi-arrow-up"></i></a>
    </div>

    <!-- JavaScript Libraries -->
    <?php echo $__env->make('layout.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Template Javascript -->
    <script src="<?php echo e(url('accessweb/js/main.js')); ?>"></script>
</body>

</html>
<?php echo $__env->make('layout.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layout.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\WorkTogether_4\resources\views/congviec/themqa.blade.php ENDPATH**/ ?>