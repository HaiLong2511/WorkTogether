
<!DOCTYPE html>
<html lang="en">

<?php $__env->startSection('Title'); ?>
    Trang Chủ
<?php $__env->stopSection(); ?>
<body>
    <div class="container-xxl position-relative bg-white d-flex p-0">
        <!-- Sidebar Start -->
        
        <!-- Sidebar End -->
        <!-- Content Start -->
        <div class="content">
            <!-- Navbar Start -->
            <nav class="navbar navbar-expand bg-light navbar-light sticky-top px-4 py-0">
                <?php echo $__env->make('layout.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </nav>
            <?php echo $__env->make('layout.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- Navbar End -->
            <div class="container-fluid pt-4 px-4">
                <div class="row g-4">
                    <div class="col-sm-12 col-xl-12">
                        <div class="bg-light rounded h-100 p-4">
                        <form action="<?php echo e(route('luutrangthai')); ?>" method="post" enctype="multipart/form-data"><?php echo csrf_field(); ?>
                        <h6 class="mb-4">Chi tiết công việc</h6>
                            <div class="form-floating mb-3">
                                <input type="text" class="form-control" name="magiao" value="<?php echo e($data->magiao); ?> " readonly>
                                <label for="floatingInput">Mã Giao Việc</label>
                            </div>
                            <div class="form-floating mb-3">
                                <input type="text" class="form-control" name="MaCV" value="<?php echo e($data->MaCV); ?> " readonly>
                                <label for="floatingInput">Mã Công Việc</label>
                            </div>
                            <div class="form-floating mb-3">
                                <input type="text" class="form-control"  value="<?php echo e(old('tencv',$data->Tieude)); ?>" readonly>
                                <label for="floatingInput">Tên Công Việc</label>
                            </div>
                            <div class="form-floating mb-3">
                                <input type="Date" class="form-control"  value="<?php echo e($data->NgayGiao); ?>" readonly>
                                <label for="floatingInput">Ngày giao công việc</label>
                            </div>
                            <div class="form-floating mb-3">
                                <input type="Date" class="form-control"  value="<?php echo e(old('ngaykt', $data->HanDK)); ?>" readonly>
                                <label for="floatingInput">Hạn nộp</label>
                            </div>
                            
                            <div class="form-floating mb-3">
                                <textarea class="form-control" placeholder=""
                                 style="height: 150px;" readonly><?php echo e(old('Mota',$data->Noidung )); ?></textarea>
                                <label for="floatingTextarea">Mô tả công việc</label>
                            </div>
                            <div class="form-floating mb-3">
                                <input type="number" class="form-control"  value="<?php echo e(old('diem',$data->diem)); ?>" readonly>
                                <label for="floatingInput">Điểm</label>
                            </div>
                            <div class="form-floating mb-3">
                                <textarea class="form-control" placeholder=""
                                style="height: 150px;" readonly><?php echo e(old('noidungnhanxet',$data->Nhanxet )); ?></textarea>
                                <label for="floatingTextarea">Nhận xét</label>
                            </div>
                            <div class="mb-3">
                                <label for="formFileMultiple" class="form-label">Chọn tệp hồ sơ</label>
                                <input class="form-control" type="file" name="formFileMultiple[]" multiple>
                            </div>
                            <div class="form-floating mb-3">
                                <select class="form-select" name="trangthai"
                                    aria-label="Floating label select example">
                                        <option <?php if($data ->Trangthai == 0 ): ?> { selected } <?php endif; ?> value = "0" >Đã giao</option>
                                        <option <?php if($data ->Trangthai == 1 ): ?> { selected } <?php endif; ?> value = "1" >Đang thực hiện</option>
                                        <option <?php if($data ->Trangthai == 2 ): ?> { selected } <?php endif; ?> value = "2" >Đã hoàn thành</option>
                                </select>
                                <label for="floatingSelect">Trạng thái</label>
                            </div>
                            <div class="form-floating mb-3">
                                <h6 class="mb-4">Tài liệu công việc</h6>
                                <?php if(!empty($data->hscv)): ?>
                                        <?php $__currentLoopData = $data->hscv; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <a href="<?php echo e(url("download/$hs->duongdan")); ?>">"<?php echo e($hs->duongdan); ?>"</a>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                </div>
                            <button type="submit" class="btn btn-primary">Lưu</button>
                            <a href="<?php echo e(url('/congviec/themqa/')); ?>/<?php echo e($data->MaCV); ?>"><button type="button" class="btn btn-primary">Thêm câu hỏi</i></button></a>
                            <a href="<?php echo e(url('/nhatky/themnhatky/')); ?>/<?php echo e($data->MaCV); ?>"><button type="button" class="btn btn-primary">Ghi nhật ký</i></button></a>
                        </form>
                        </div>
                    </div>
                    <div class="col-sm-12 col-xl-12">
                        <div class="bg-light rounded h-100 p-4">
                            <h6 class="mb-4">Hồ sơ công việc</h6>
                            <ul class="nav nav-pills mb-3" id="pills-tab" role="tablist">
                                <li class="nav-item" role="presentation">
                                    <button class="nav-link active" id="pills-home-tab" data-bs-toggle="pill"
                                        data-bs-target="#pills-home" type="button" role="tab" aria-controls="pills-home"
                                        aria-selected="true">Q/A</button>
                                </li>
                                <li class="nav-item" role="presentation">
                                    <button class="nav-link" id="pills-profile-tab" data-bs-toggle="pill"
                                        data-bs-target="#pills-profile" type="button" role="tab"
                                        aria-controls="pills-profile" aria-selected="false">Nhật ký</button>
                                </li>
                                <li class="nav-item" role="presentation">
                                    <button class="nav-link" id="pills-contact-tab" data-bs-toggle="pill"
                                        data-bs-target="#pills-contact" type="button" role="tab"
                                        aria-controls="pills-contact" aria-selected="false">Lịch sử</button>
                                </li>
                            </ul>
                            <div class="tab-content" id="pills-tabContent">
                                <div class="tab-pane fade show active" id="pills-home" role="tabpanel" aria-labelledby="pills-home-tab">
                                    <?php if(!empty($data->qa)): ?>
                                    <?php $__currentLoopData = $data->qa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-sm-12 col-xl-12">
                                        <div class="bg-light rounded h-100 p-4">
                                            <h6 class="mb-4"><?php echo e($item->TenNV); ?> <i> - <?php echo e(date('d-m-Y', strtotime($item->ngayghiqa))); ?></i></h6>
                                            <div class="tab-content" id="pills-tabContent">
                                                <div class="tab-pane fade show active" id="pills-home" role="tabpanel" aria-labelledby="pills-home-tab">
                                                    - Nội dung: <?php echo e($item->Noidungqa); ?> 
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </div>
                                <div class="tab-pane fade" id="pills-profile" role="tabpanel" aria-labelledby="pills-profile-tab">
                                    <div class="tab-pane fade show active" id="pills-home" role="tabpanel" aria-labelledby="pills-home-tab">
                                        <?php if(!empty($data->nkhn)): ?>
                                        <?php $__currentLoopData = $data->nkhn; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-sm-12 col-xl-12">
                                            <div class="bg-light rounded h-100 p-4">
                                                <h6 class="mb-4"><?php echo e($item->TenNV); ?> <i> - <?php echo e(date('d-m-Y', strtotime($item->NgayTao))); ?></i></h6>
                                                <div class="tab-content" id="pills-tabContent">
                                                    <div class="tab-pane fade show active" id="pills-home" role="tabpanel" aria-labelledby="pills-home-tab">
                                                        - Nội dung: <?php echo e($item->NoiDung); ?> 
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="tab-pane fade" id="pills-contact" role="tabpanel" aria-labelledby="pills-contact-tab">
                                    <div class="tab-pane fade show active" id="pills-home" role="tabpanel" aria-labelledby="pills-home-tab">
                                        <?php if(!empty($data->nkcn)): ?>
                                        <?php $__currentLoopData = $data->nkcn; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-sm-12 col-xl-12">
                                            <div class="bg-light rounded h-100 p-4">
                                                <h6 class="mb-4"><?php echo e($item->TenNV); ?> <i> - <?php echo e(date('d-m-Y', strtotime($item->NgayTao))); ?></i></h6>
                                                <div class="tab-content" id="pills-tabContent">
                                                    <div class="tab-pane fade show active" id="pills-home" role="tabpanel" aria-labelledby="pills-home-tab">
                                                        - Nội dung: <?php echo e($item->NoiDung); ?> 
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                         </div>
                    </div>
                </div>
            </div>

            <!-- Footer Start -->
            <?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- Footer End -->
        </div>
        <!-- Content End -->


        <!-- Back to Top -->
        <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top"><i class="bi bi-arrow-up"></i></a>
    </div>

    <!-- JavaScript Libraries -->
    <?php echo $__env->make('layout.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Template Javascript -->
    <script src="<?php echo e(url('accessweb/js/main.js')); ?>"></script>
</body>

</html>
                                
                                
                                  
                     
<?php echo $__env->make('layout.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layout.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\WorkTogether\resources\views/congviec/chitietcongviecnhanvien.blade.php ENDPATH**/ ?>