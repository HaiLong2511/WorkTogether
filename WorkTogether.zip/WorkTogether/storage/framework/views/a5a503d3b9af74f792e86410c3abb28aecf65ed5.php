<!DOCTYPE html>
<html lang="en">

<?php $__env->startSection('Title'); ?>
    Trang Chủ
<?php $__env->stopSection(); ?>
<body>
    <div class="container-xxl position-relative bg-white d-flex p-0">
        <!-- Sidebar Start -->
        
        <!-- Sidebar End -->
        <!-- Content Start -->
        <div class="content">
            <!-- Navbar Start -->
            <nav class="navbar navbar-expand bg-light navbar-light sticky-top px-4 py-0">
                <?php echo $__env->make('layout.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </nav>
            <?php echo $__env->make('layout.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- Navbar End -->
            <div class="container-fluid pt-4 px-4">
                <div class="row g-4">
                    <div class="col-sm-12 col-xl-12">
                        <div class="bg-light rounded h-100 p-4">
                            <h6 class="mb-4">Danh sách đơn vị </h6>
                            <form class="d-none d-md-flex ms-4" action="<?php echo e(route('Searchdonvi')); ?>" method="get">
                                <input class="form-control border-0" type="search" placeholder="Tìm kiếm" name="keywords">
                            </form>
                            <a href="<?php echo e(route('themdonvi')); ?>"> <button type="button" class="btn btn-square btn-primary m-2"><i class="fa fa-plus"></i></button></a>
                            <div class="table-responsive">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th scope="col">#</th>
                                            <th scope="col">Tên phòng</th>
                                            <th scope="col">Trưởng phòng</th>
                                            <th scope="col">Số lượng nhân viên</th>
                                            <th scope="col"> Thao tác </th>
                                            
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $list_dv; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($item->MaDV); ?></td>
                                            <td><?php echo e($item->TenPhong); ?></td>
                                            <td> <?php echo e($item->tentp); ?></td>
                                            <td> <?php echo e($item->soluong); ?></td>
                                            <td>
                                                <a href="<?php echo e(url('donvi/chitietdonvi/')); ?>/<?php echo e($item->MaDV); ?>"><button type="button" class="btn btn-sm btn-sm-square btn-outline-primary m-2"><i class="fa fa-info"></i></button></a>
                                                <!-- <a href="<?php echo e(url("XoaDonVi/{$item->MaDV}")); ?>"  type="button" class="btn btn-sm btn-sm-square btn-outline-primary m-2"><i class="fa fa-del"></i> Xóa </button> </a>  -->
                                            </td> 
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                                <div>
                                    <?php echo e($list_dv->links()); ?>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Footer Start -->
            <?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- Footer End -->
        </div>
        <!-- Content End -->


        <!-- Back to Top -->
        <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top"><i class="bi bi-arrow-up"></i></a>
    </div>

    <!-- JavaScript Libraries -->
    <?php echo $__env->make('layout.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Template Javascript -->
    <script src="<?php echo e(url('accessweb/js/main.js')); ?>"></script>
</body>

</html>
<?php echo $__env->make('layout.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layout.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\WorkTogether_4\resources\views/donvi/listdonvi.blade.php ENDPATH**/ ?>