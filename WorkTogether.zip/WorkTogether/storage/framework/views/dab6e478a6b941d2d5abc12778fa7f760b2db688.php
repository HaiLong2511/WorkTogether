<!DOCTYPE html>
<html>
<head>
	<title>Đăng Nhập</title>
	<link rel="stylesheet" type="text/css" href="<?php echo e(url('access/css/style.css')); ?>">
	<link href="https://fonts.googleapis.com/css?family=Poppins:600&display=swap" rel="stylesheet">
	<script src="https://kit.fontawesome.com/a81368914c.js"></script>
	<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
	<img class="wave" src="<?php echo e(url('access/img/wave.png')); ?>">
	<div class="container">
		<div class="img">
			<img src="<?php echo e(url('access/img/bg.svg')); ?>">
		</div>
		<div class="login-content">
			<form action="<?php echo e(route('checklogin')); ?>" method="post" enctype="multipart/form-data">
				<?php echo csrf_field(); ?>
				<img src="<?php echo e(url('access/img/avatar.svg')); ?>">
				<h2 class="title">Xin Chào</h2>
           		<div class="input-div one">
           		   <div class="i">
           		   		<i class="fas fa-user"></i>
           		   </div>
           		   <div class="div">
           		   		<h5>Tên Đăng Nhập</h5>
           		   		<input type="text" class="input" name="user_id" required >
           		   </div>
           		</div>
           		<div class="input-div pass">
           		   <div class="i"> 
           		    	<i class="fas fa-lock"></i>
           		   </div>
           		   <div class="div">
           		    	<h5>Mật Khẩu</h5>
           		    	<input type="password" class="input" name="passwd" required>
            	   </div>
            	</div>
				<a href="<?php echo e(route('quenmatkhau')); ?>">Quên Mật Khẩu?</a>
				<?php if(session()->has('mess')): ?>
				<div style="color:red;" >
					<?php echo e(session('mess')); ?>

				</div>
				<?php endif; ?>
            	<input type="submit" class="btn" value="Đăng Nhập">
            </form>
        </div>
    </div>
    <script type="text/javascript" src="<?php echo e(url('access/js/main.js')); ?>"></script>
</body>
</html><?php /**PATH C:\wamp64\www\WorkTogether_4\resources\views/login.blade.php ENDPATH**/ ?>