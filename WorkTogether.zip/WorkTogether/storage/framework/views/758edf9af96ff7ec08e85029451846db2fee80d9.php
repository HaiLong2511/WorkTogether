<!DOCTYPE html>
<html lang="en">

<?php $__env->startSection('Title'); ?>
    Trang Chủ
<?php $__env->stopSection(); ?>
<body>
    <div class="container-xxl position-relative bg-white d-flex p-0">
        <!-- Sidebar Start -->
        
        <!-- Sidebar End -->
        <!-- Content Start -->
        <div class="content">
            <!-- Navbar Start -->
            <nav class="navbar navbar-expand bg-light navbar-light sticky-top px-4 py-0">
                <?php echo $__env->make('layout.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </nav>
            <?php if(session()->has('mess')): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <i class="fa fa-exclamation-circle me-2"></i><?php echo e(session('mess')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
			<?php endif; ?>
            <?php if(session()->has('success')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <?php echo e(session('success')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
			<?php endif; ?>
            <!-- Navbar End -->
            <!-- Widgets Start -->
            <form action="<?php echo e(route('xemthongke')); ?>" method="post" enctype="multipart/form-data"><?php echo csrf_field(); ?>
            <div class="container-fluid pt-4 px-4">
                <div class="row g-4">
                    <div class="col-sm-12 col-xl-12">
                        <div class="h-100 bg-light rounded p-4">
                            <select name = "month" >
                                <option selected value="">Chọn tháng</option>      
                                 <?php for($month = 1; $month <= 12 ; $month++): ?>                  
                                 <option value = "<?php echo e($month); ?>"><?php echo e($month); ?></option>                  
                                 <?php endfor; ?>
                            </select>
                            <input type="text" name="year" min="1900" max="2099" step="1" value="2022" placeholder="Năm" />
                            <select name ="mscv">
                                <option value="" selected>Chọn công việc</option>
                                <?php $__currentLoopData = $data->dscv; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->MaCV); ?>" ><?php echo e($item->Tieude); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <select name="msnv">
                                <option value="" selected>Chọn nhân viên</option>
                                <?php $__currentLoopData = $data->dsnv; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->MaNV); ?>" ><?php echo e($item->TenNV); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <button type="submit" class="btn btn-primary">Xem</button>
                        </div>
                    </div>
                </div>
            </div>
        </form>
            <!-- Widgets End -->
            <!-- Footer Start -->
            <div class="container-fluid pt-4 px-4">
                <div class="row g-4">
                <?php if(!empty($data)): ?>
                <div class="container-fluid pt-4 px-4">
                    <div class="bg-light text-center rounded p-4">
                        <div class="table-responsive">
                            <table class="table text-start align-middle table-bordered table-hover mb-0">
                                <thead>
                                    <tr class="text-dark">
                                        <th scope="col">Từ </th>
                                        <th scope="col">Đến</th>
                                        <th scope="col">tên nhân viên </th>
                                        <th scope="col">Tên Công việc</th>
                                        <th scope="col">Số giờ</th>
                                        <th scope="col">Số Nhật ký</th>
                                        <th scope="col">Số điểm</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($item->NgayGiao); ?></td>
                                        <td><?php echo e($item->HanTT); ?></td>
                                        <td><?php echo e($item->TenNV); ?></td>
                                        <td><?php echo e($item->Tieude); ?></td>
                                        <td><?php echo e($item->sogio); ?></td>
                                        <td><?php echo e($item->sonk); ?></td>
                                        <td><?php echo e($item->diem); ?></td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                    <?php endif; ?>
                </div>
            </div>
            <?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- Footer End -->
        </div>
        <!-- Content End -->


        <!-- Back to Top -->
        <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top"><i class="bi bi-arrow-up"></i></a>
    </div>

    <!-- JavaScript Libraries -->
    <?php echo $__env->make('layout.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Template Javascript -->
    <script src="<?php echo e(url('accessweb/js/main.js')); ?>"></script>
</body>

</html>
<?php echo $__env->make('layout.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layout.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\WorkTogether\resources\views/thongke/thongke.blade.php ENDPATH**/ ?>