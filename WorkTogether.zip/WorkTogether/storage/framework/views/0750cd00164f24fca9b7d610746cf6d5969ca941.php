
<!DOCTYPE html>
<html lang="en">

<?php $__env->startSection('Title'); ?>
    Trang Chủ
<?php $__env->stopSection(); ?>
<body>
    <div class="container-xxl position-relative bg-white d-flex p-0">
        <!-- Sidebar Start -->
        
        <!-- Sidebar End -->
        <!-- Content Start -->
        <div class="content">
            <!-- Navbar Start -->
            <nav class="navbar navbar-expand bg-light navbar-light sticky-top px-4 py-0">
                <?php echo $__env->make('layout.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </nav>
            <?php echo $__env->make('layout.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- Navbar End -->
            <div class="container-fluid pt-4 px-4">
                <div class="row g-4">
                    <div class="col-sm-12 col-xl-12">
                        <div class="bg-light rounded h-100 p-4">
                        <form action="<?php echo e(route('SuaNhanVien')); ?>" method="post" enctype="multipart/form-data"><?php echo csrf_field(); ?>
                            <h5 class="mb-4">Chi tiết nhân viên  </h5>
                                <input type="hidden" value="<?php echo e($data->MaNV); ?>" name="manv">

                                <div class="mb-3">
                                    <label for="" class="form-label"> <b>Tên nhân viên</b> </label>
                                    
                                    <input value="<?php echo e($data->TenNV); ?>" type="text"class="form-control" id=""  name="tennv">
                                </div>
                                <div class="mb-3">
                                    <label for="" class="form-label"> <b>Giới tính</b></label>
                                    
                                    <select id=""  class="form-control" name="gioitinh">
                                        <option value="0" <?php if($data->Gt): ?>
                                            <?php echo e("selected"); ?>

                                        <?php endif; ?>>Nam</option>
                                        <option value="1" <?php if(!$data->Gt): ?>
                                            <?php echo e("selected"); ?>

                                        <?php endif; ?>>Nữ</option>
                                    </select>
                                </div>

                                <div class="mb-3">
                                    <label for="" class="form-label"><b>Ngày sinh</b></label>
                                    <input type="date" class="form-control" id="" value="<?php echo e($data->NgaySinh); ?>" name="ngaysinh">
                                </div>
                                <div class="mb-3">
                                    <label for="exampleInputEmail1" class="form-label"><b>Email</b></label>
                                    <input type="email" class="form-control" id="exampleInputEmail1"
                                        aria-describedby="emailHelp"  value="<?php echo e($data->Email); ?>" name="email">
                                    <div id="emailHelp" class="form-text">
                                    </div>
                                </div>
                                <div class="mb-3">
                                    <label for="" class="form-label"><b>Số điện thoại</b></label>
                                    <input type="" class="form-control" id="" value="<?php echo e($data->SDT); ?>"  name="sdt">
                                </div>
                                <div class="mb-3">
                                    <label for="" class="form-label"><b>Địa chỉ</b></label>
                                    <input type="" class="form-control" id=""  value="<?php echo e($data->DiaChi); ?>" name="diachi">
                                </div>
                                
                                <button type="submit" class="btn btn-primary"> Sửa </button>
                                <a href="<?php echo e(url("XoaNhanVien/{$data->MaNV}")); ?>"  class="btn btn-primary">Xóa </a> 
                              
                            
                        </form>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Footer Start -->
            <?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- Footer End -->
        </div>
        <!-- Content End -->


        <!-- Back to Top -->
        <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top"><i class="bi bi-arrow-up"></i></a>
    </div>

    <!-- JavaScript Libraries -->
    <?php echo $__env->make('layout.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Template Javascript -->
    <script src="<?php echo e(url('accessweb/js/main.js')); ?>"></script>
</body>

</html>
<?php echo $__env->make('layout.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layout.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\WorkTogether_4\resources\views/admin/qlnv/chitietnhanvien.blade.php ENDPATH**/ ?>