
<!DOCTYPE html>
<html lang="en">

<?php $__env->startSection('Title'); ?>
    Trang Chủ
<?php $__env->stopSection(); ?>
<body>
    <div class="container-xxl position-relative bg-white d-flex p-0">
        <!-- Sidebar Start -->
        
        <!-- Sidebar End -->
        <!-- Content Start -->
        <div class="content">
            <!-- Navbar Start -->
            <nav class="navbar navbar-expand bg-light navbar-light sticky-top px-4 py-0">
                <?php echo $__env->make('layout.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </nav>
                <div class="container-fluid pt-4 px-4">
                    <div class="row g-4">
                        <div class="col-sm-12 col-xl-12">
                            <div class="bg-light rounded h-100 p-4">
                                <h6 class="mb-4">Thông Tin Nhân Viên:</h6>
                                <div class="testimonial-item text-center">
                                    <img class="img-fluid rounded-circle mx-auto mb-4" src="<?php echo e(url('accessweb/img/'.$user_info ->Avt)); ?>" style="width: 100px; height: 100px;">
                                    <h5 class="mb-1">Tên Nhân Viên: <?php echo e($user_info->TenNV); ?></h5>
                                    <p>Chức vụ <?php echo e($user_info->TenQuyen); ?></p>
                                    <p>Tên Đơn Vị: <?php echo e($user_info->TenPhong); ?></p>
                                    <p>Giới Tính: <?php if($user_info->Gt): ?>
                                        <?php echo e("Nữ"); ?>

                                    <?php else: ?>
                                        <?php echo e("Nam"); ?>

                                    <?php endif; ?> </p>
                                    <p>Ngày Sinh: <?php echo e($user_info->NgaySinh); ?></p>
                                    <p>Email: <?php echo e($user_info->Email); ?></p>
                                    <p>Số Điện Thoại: <?php echo e($user_info->SDT); ?></p>
                                    <p>Địa Chỉ: <?php echo e($user_info->DiaChi); ?></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div> 
            <!-- Navbar End -->
            
            <!-- Footer Start -->
            <?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- Footer End -->
        </div>
        <!-- Content End -->


        <!-- Back to Top -->
        <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top"><i class="bi bi-arrow-up"></i></a>
    </div>

    <!-- JavaScript Libraries -->
    <?php echo $__env->make('layout.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Template Javascript -->
    <script src="<?php echo e(url('accessweb/js/main.js')); ?>"></script>
</body>

</html>
<?php echo $__env->make('layout.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layout.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\WorkTogether\resources\views/user/thongtincanhan.blade.php ENDPATH**/ ?>